<?
$text = "|";
$filename = "nazioni.txt";

$phrase = preg_grep ("/" . preg_quote ($text) . "/i", file ($filename));
include 'include/connectdb.php' //dove solamente creare un db con la tabella "nazioni" e due colonne con il nome "suffisso" e "stato"
foreach ($phrase as $p) {
   $nazione = strstr($p, '|');
   $nazione = str_replace("|", "", $nazione);
   $s = substr($p, 0, 2);
   $ins = "INSERT INTO `nazioni` (`suffisso` ,`stato`) VALUES ('$s', '$nazione')";
   $exe = mysql_query($ins);
}
?>
